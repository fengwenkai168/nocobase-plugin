import { useState, useEffect } from 'react';
import { useCurrentUserContext } from '@nocobase/client-v2';

export function useTablePermission(api: any, tableName: string | undefined) {
  const [allowedModes, setAllowedModes] = useState<string[]>(['insert', 'update', 'upsert']);
  const [loading, setLoading] = useState(false);
  const { data: currentUser } = useCurrentUserContext();

  useEffect(() => {
    if (!tableName) return;
    const userId = currentUser?.data?.data?.id || currentUser?.data?.id;
    if (!userId) {
      setAllowedModes(['insert', 'update', 'upsert']);
      return;
    }
    setLoading(true);
    api.request({
      url: 'sjgl02Permissions:get',
      method: 'get',
      params: { targetType: 'user', targetId: String(userId) },
    }).then((res: any) => {
      const data = res?.data?.data || {};
      const userPerm = (data.custom || []).find((p: any) => p.tableName === tableName);
      if (userPerm) {
        if (userPerm.canImport && userPerm.importMode) {
          setAllowedModes(Array.isArray(userPerm.importMode) ? userPerm.importMode : [userPerm.importMode]);
        } else {
          setAllowedModes([]);
        }
        return;
      }
      const rolePerm = (data.inherited || []).find((p: any) => p.tableName === tableName && p.canImport);
      if (rolePerm?.importMode) {
        setAllowedModes(Array.isArray(rolePerm.importMode) ? rolePerm.importMode : [rolePerm.importMode]);
      } else {
        setAllowedModes(['insert', 'update', 'upsert']);
      }
    }).catch(() => setAllowedModes(['insert', 'update', 'upsert']))
      .finally(() => setLoading(false));
  }, [api, tableName, currentUser]);

  return { allowedModes, loading };
}
