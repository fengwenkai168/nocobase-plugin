// @ts-nocheck
import React from 'react';
import { useAPIClient } from '@nocobase/client';
import { Card, Tabs, Button, Space, Select, Table, Tag, Statistic, Row, Col, Input, InputNumber, message, Checkbox, Switch, Steps, Progress, Empty, Descriptions, Drawer, Modal, Form, Radio, Upload, Pagination, Alert } from 'antd';
import { InboxOutlined, TableOutlined } from '@ant-design/icons';
import { VERSION, apiRequest } from './shared';

const { Dragger } = Upload;

export default function ImportPanel() {
  const client = useAPIClient();
  const [step, setStep] = React.useState(0);
  const [selectedTable, setSelectedTable] = React.useState<any>(null);
  const [importMode, setImportMode] = React.useState('insert');
  const [allowedModes, setAllowedModes] = React.useState<string[]>(['insert', 'update', 'upsert']);
  const [uploadedFileId, setUploadedFileId] = React.useState<number | null>(null);
  const [uploadedFileName, setUploadedFileName] = React.useState('');
  const [tableFields, setTableFields] = React.useState<any[]>([]);
  const [previewData, setPreviewData] = React.useState<any>(null);
  const [uniqueFields, setUniqueFields] = React.useState<string[]>([]);
  const [fieldMapping, setFieldMapping] = React.useState<Record<string, string>>({});
  const [customValues, setCustomValues] = React.useState<Record<string, string>>({});
  const [excelHeaders, setExcelHeaders] = React.useState<string[]>([]);
  const [sheetName, setSheetName] = React.useState('Sheet1');
  const [headerRow, setHeaderRow] = React.useState(1);
  const [availSheets, setAvailSheets] = React.useState<string[]>(['Sheet1']);
  const [previewModal, setPreviewModal] = React.useState(false);
  const [previewMeta, setPreviewMeta] = React.useState<any>(null);

  const doParse = () => {
    if (!uploadedFileId) return;
    setFieldMapping({});
    setCustomValues({});
    setUniqueFields([]);
    client.request({ url: 'sjgl02Import:uploadParse', method: 'post', data: { fileId: uploadedFileId, sheetName, headerRow } })
      .then((pr: any) => {
        const pd = pr?.data?.data;
        if (pd?.headerColumns) setExcelHeaders(pd.headerColumns);
        if (pd?.sheets) { setAvailSheets(pd.sheets); }
        setPreviewMeta(pd);
      }).catch(() => { setExcelHeaders([]); setAvailSheets([]); setPreviewMeta(null); });
  };

  React.useEffect(() => { doParse(); }, [sheetName, headerRow]);

  const [tables, setTables] = React.useState<any[]>([]);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    apiRequest(client, 'sjgl02Permissions:tables').then((data) => {
      if (Array.isArray(data)) {
        setTables(data.map((t: any) => ({ name: t.name, title: t.title || t.name })));
      }
    }).catch(() => message.error('加载表列表失败')).finally(() => setLoading(false));
  }, []);

  React.useEffect(() => {
    if (selectedTable?.name) {
      client.request({ url: 'sjgl02Import:tableFields', method: 'get', params: { tableName: selectedTable.name } })
        .then((res: any) => {
          const fields = res?.data?.data || [];
          setTableFields(Array.isArray(fields) ? fields : []);
        })
        .catch(() => {});
    }
  }, [selectedTable?.name]);

  React.useEffect(() => {
    if (selectedTable?.name) {
      apiRequest(client, 'auth:check').then((userData: any) => {
        const currentUserId = userData?.data?.id || userData?.id;
        if (!currentUserId) { setAllowedModes(['insert', 'update', 'upsert']); return; }
        apiRequest(client, 'sjgl02Permissions:get', { params: { targetType: 'user', targetId: String(currentUserId) } }).then((permData: any) => {
          const userPerm = (permData?.custom || []).find((p: any) => p.tableName === selectedTable.name);
          if (userPerm) {
            if (userPerm.canImport && userPerm.importMode) {
              setAllowedModes(Array.isArray(userPerm.importMode) ? userPerm.importMode : [userPerm.importMode]);
            } else {
              setAllowedModes([]);
            }
            return;
          }
          const rolePerm = (permData?.inherited || []).find((p: any) => p.tableName === selectedTable.name && p.canImport);
          if (rolePerm?.importMode) {
            setAllowedModes(Array.isArray(rolePerm.importMode) ? rolePerm.importMode : [rolePerm.importMode]);
          } else {
            setAllowedModes(['insert', 'update', 'upsert']);
          }
        }).catch(() => setAllowedModes(['insert', 'update', 'upsert']));
      }).catch(() => setAllowedModes(['insert', 'update', 'upsert']));
    }
  }, [selectedTable?.name]);

  const handleFileSelect = (info: any) => {
    if (info.file.status === 'done') {
      const resp = info.file.response;
      const fileId = resp?.id;
      if (fileId) {
        setUploadedFileId(fileId);
        setUploadedFileName(info.file.name);
        message.success(`${info.file.name} 上传成功`);
          client.request({ url: 'sjgl02Import:uploadParse', method: 'post', data: { fileId } })
            .then((pr: any) => {
              const pd = pr?.data?.data;
              if (pd?.headerColumns) setExcelHeaders(pd.headerColumns);
              if (pd?.sheets) { setAvailSheets(pd.sheets); if (pd.sheets[0]) setSheetName(pd.sheets[0]); }
              setPreviewMeta(pd);
            }).catch(() => { setExcelHeaders([]); setAvailSheets(['Sheet1']); setPreviewMeta(null); });
      } else {
        message.error('上传响应中未找到文件ID');
      }
    } else if (info.file.status === 'error') {
      message.error('上传失败，请重试');
    }
  };

  const handlePreview = () => {
    if (!uploadedFileId) return;
    client.request({
      url: 'sjgl02Import:preview',
      method: 'get',
      params: { fileId: uploadedFileId, sheetName, headerRow },
    }).then((res: any) => {
      setPreviewData(res?.data?.data || null);
    }).catch((err: any) => {
      const msg = err?.response?.data?.errors?.[0]?.message || err?.message || '预览失败';
      message.error(msg);
    });
  };

  const handleAutoMatch = () => {
    const mapping: Record<string, string> = {};
    tableFields.forEach((f) => {
      const match = excelHeaders.find((h: string) =>
        h === f.name || h.toLowerCase() === f.name.toLowerCase()
      );
      if (match) mapping[f.name] = match;
    });
    setFieldMapping(mapping);
    message.success('自动匹配完成');
  };

  const handleExecute = () => {
    Modal.confirm({
      title: '确认导入',
      content: '导入在事务中执行，任一行失败则整批回滚。关联字段通过主键ID匹配，匹配失败则整批回滚。',
      onOk: () => {
        client.request({
          url: 'sjgl02Import:execute',
          method: 'post',
          data: {
            tableName: selectedTable?.name,
            fileId: uploadedFileId,
            sheetName,
            headerRow,
            fieldMapping,
            customValues,
            importMode,
            uniqueFields,
          },
        }).then(() => {
          message.success('导入任务已提交，可在任务管理中查看进度');
          setStep(0); setSelectedTable(null); setUploadedFileId(null);
          setUploadedFileName(''); setFieldMapping({}); setPreviewData(null);
          setCustomValues({}); setExcelHeaders([]); setAvailSheets(['Sheet1']);
        }).catch(() => message.error('提交失败'));
      },
    });
  };

  return (
    <div>
      <Steps current={step} items={[{ title: '选择数据表' }, { title: '上传文件 & 字段映射' }, { title: '预览 & 执行' }]} style={{ marginBottom: 24 }} />
      {step === 0 && (
        <div>
          <Row gutter={16}>
            <Col span={12}>
              <Card title="📋 选择目标数据表" size="small">
                <Select style={{ width: '100%' }} placeholder="— 请选择数据表 —" loading={loading} showSearch
                  value={selectedTable?.name || undefined}
                  onChange={(val) => setSelectedTable(tables.find(t => t.name === val) || null)}
                  filterOption={(input, option) => String(option?.label || '').toLowerCase().includes(input.toLowerCase())}
                  options={tables.map((t) => ({ value: t.name, label: `📁 ${t.title} (${t.name})` }))} />
                <div style={{ fontSize: 11, color: '#999', marginTop: 4 }}>共 {tables.length} 张表</div>
              </Card>
            </Col>
            <Col span={12}>
              <Card title="ℹ️ 导入说明" size="small">
                <div style={{ fontSize: 13, color: '#666', lineHeight: 1.9 }}>
                  <p>• 支持 <strong>.xlsx</strong> / <strong>.xls</strong> / <strong>.csv</strong></p>
                  <p>• 文件最大 <strong>50 MB</strong></p>
                  <p>• 三种模式：<Tag color="blue">新增</Tag> <Tag color="green">更新</Tag> <Tag color="orange">新增+更新</Tag></p>
                </div>
              </Card>
            </Col>
          </Row>
          <div style={{ textAlign: 'right', marginTop: 12 }}>
            <Button type="primary" disabled={!selectedTable} onClick={() => setStep(1)}>下一步 →</Button>
          </div>
        </div>
      )}
      {step === 1 && (
        <div>
          {!uploadedFileId ? (
            <Dragger name="file" multiple={false} accept=".xlsx,.xls,.csv"
              customRequest={({ file, onSuccess, onError }: any) => {
                const fd = new FormData();
                fd.append('file', file);
                client.request({ url: 'attachments:create', method: 'post', data: fd })
                  .then((r: any) => {
                    const d = r?.data?.data ?? r?.data;
                    onSuccess({ id: d?.id, ...d }, file);
                  })
                  .catch(onError);
              }}
              onChange={handleFileSelect}
              beforeUpload={(file) => {
                const ext = file.name.split('.').pop()?.toLowerCase();
                if (!['xlsx', 'xls', 'csv'].includes(ext || '')) { message.error('不支持的文件格式'); return Upload.LIST_IGNORE; }
                if (file.size > 50 * 1024 * 1024) { message.error('文件超过 50MB 限制'); return Upload.LIST_IGNORE; }
                return true;
              }}
              style={{ marginBottom: 20 }}>
              <p className="ant-upload-drag-icon"><InboxOutlined /></p>
              <p className="ant-upload-text">点击或拖拽上传文件</p>
              <p className="ant-upload-hint">支持 .xlsx / .xls / .csv，最大 50MB</p>
            </Dragger>
          ) : (
            <div>
              <Card size="small" style={{ marginBottom: 12 }}>
                <Tag color="blue">{uploadedFileName}</Tag>
                <Button size="small" style={{ marginLeft: 8 }}
                  onClick={() => { setUploadedFileId(null); setUploadedFileName(''); setExcelHeaders([]); setFieldMapping({}); }}>
                  重新上传
                </Button>
                <Space style={{ marginLeft: 16 }}>
                  <span style={{ color: '#999' }}>Sheet：</span>
                  <Select value={sheetName} onChange={setSheetName} style={{ width: 120 }}
                    options={availSheets.map(s => ({ value: s, label: s }))} />
                   <span style={{ color: '#999' }}>表头行：</span>
                   <InputNumber min={1} max={100} value={headerRow} onChange={v => setHeaderRow(v || 1)} style={{ width: 70 }} />
                   <Button size="small" icon={<TableOutlined />}
                     disabled={!previewMeta?.previewRows?.length}
                     onClick={() => setPreviewModal(true)}>预览表头</Button>
                   {previewMeta && (
                     <span style={{ color: '#999', fontSize: 12 }}>
                       共 {previewMeta.headerColumns?.length || 0} 列 / {previewMeta.totalRows || 0} 行数据
                     </span>
                   )}
                 </Space>
              </Card>
              <Card size="small" style={{ marginBottom: 12 }}>
                <Space>
                  <span style={{ color: '#999' }}>导入模式：</span>
                  <Select value={importMode} onChange={setImportMode} style={{ width: 220 }}
                    options={[
                      { value: 'insert', label: '新增 (insert)' },
                      { value: 'update', label: '更新 (update)' },
                      { value: 'upsert', label: '新增+更新 (upsert)' },
                    ].filter(o => allowedModes.includes(o.value))} />
                </Space>
              </Card>
              {(importMode === 'update' || importMode === 'upsert') && (
                <Card size="small" style={{ marginBottom: 12 }}>
                  <div style={{ fontWeight: 600, color: '#fa8c16', marginBottom: 8 }}>🔑 唯一值字段</div>
                  <Select mode="multiple" value={uniqueFields} onChange={setUniqueFields}
                    style={{ width: '100%' }} placeholder="选择唯一值字段"
                    options={tableFields.map((f: any) => ({ value: f.name, label: (f.uiSchema?.title || f.name) + '(' + f.name + ')' }))} />
                </Card>
              )}
              {excelHeaders.length > 0 && (
                <Card size="small" title={<span>📊 字段映射（{tableFields.length}字段/已映射{Object.values(fieldMapping).filter(v=>v&&v!=='__ignore__').length}）<Button size="small" style={{ marginLeft: 12 }} onClick={handleAutoMatch}>⚡ 自动匹配</Button></span>} style={{ marginBottom: 12 }}>
                  <Table
                    dataSource={tableFields.map((f: any, i: number) => ({ field: f, key: i }))}
                    columns={[
                      {
                        title: 'Excel列 / 自定义值',
                        width: 220,
                        render: (record: any) => {
                          const isUpdatedAt = record.field?.interface === 'updatedAt';
                          const val = fieldMapping[record.field.name];
                          const isCustom = val === '__custom__';
                          const used = Object.values(fieldMapping).filter(v => v && v !== '__ignore__' && v !== '__custom__');
                          return (
                            <div>
                              {isUpdatedAt ? (
                                <span style={{ color: '#999', lineHeight: '32px' }}>—</span>
                              ) : (
                                <Select style={{ width: '100%' }} placeholder="忽略" value={val || undefined}
                                  onChange={v => setFieldMapping(prev => ({ ...prev, [record.field.name]: v }))} allowClear>
                                  <Select.Option value="__ignore__">🚫 忽略</Select.Option>
                                  <Select.Option value="__custom__">✏️ 自定义固定值</Select.Option>
                                  {excelHeaders.map((h: string) => (
                                    <Select.Option key={h} value={h} disabled={used.includes(h) && val !== h}>
                                      {h}{used.includes(h) && val !== h ? ' (已用)' : ''}
                                    </Select.Option>
                                  ))}
                                </Select>
                              )}
                              {isCustom && !isUpdatedAt && (
                                <Input size="small" style={{ marginTop: 4 }} placeholder="输入固定值"
                                  value={customValues[record.field.name] || ''}
                                  onChange={e => setCustomValues(prev => ({ ...prev, [record.field.name]: e.target.value }))} />
                              )}
                            </div>
                          );
                    },
                      },
                    { title: '→', width: 30, render: () => <span style={{ color: '#999' }}>→</span> },
                      {
                        title: '映射方式',
                        width: 80,
                        render: (record: any) => {
                          if (record.field?.interface === 'updatedAt') return <Tag color="orange">🔒 只读</Tag>;
                          const val = fieldMapping[record.field.name];
                          if (!val || val === '__ignore__') return <Tag>忽略</Tag>;
                          if (val === '__custom__') return <Tag color="green">固定值</Tag>;
                          return <Tag color="blue">Excel列</Tag>;
                        },
                      },
                      { title: '→', width: 30, render: () => <span style={{ color: '#999' }}>→</span> },
                      {
                        title: '工作表字段',
                        width: 150,
                        render: (record: any) => (
                          <span>
                            {record.field.isRequired && <span style={{ color: '#ff4d4f' }}>* </span>}
                            {record.field.uiSchema?.title || record.field.name}({record.field.name})
                            {uniqueFields.includes(record.field.name) && <Tag color="orange" style={{ marginLeft: 4, fontSize: 10 }}>🔑 唯一值</Tag>}
                          </span>
                        ),
                      },
                    ] as any}
                    pagination={false} size="small" />
                </Card>
      )}
      <Modal title="📋 表头及预览数据" open={previewModal} onCancel={() => setPreviewModal(false)}
        footer={<Button onClick={() => setPreviewModal(false)}>关闭</Button>}
        width={800}>
        {previewMeta && (
          <div>
            <Descriptions size="small" column={3} bordered style={{ marginBottom: 12 }}>
              <Descriptions.Item label="Sheet">{sheetName}</Descriptions.Item>
              <Descriptions.Item label="表头行">{headerRow}</Descriptions.Item>
              <Descriptions.Item label="数据行数">{previewMeta.totalRows || 0}</Descriptions.Item>
            </Descriptions>
            <Table dataSource={previewMeta.previewRows?.map((row: any, idx: number) => ({ ...row, __rowKey: idx })) || []}
              rowKey="__rowKey"
              columns={previewMeta.headerColumns?.map((h: string) => ({ title: h, dataIndex: h, ellipsis: true })) || []}
              pagination={false} size="small" scroll={{ x: 'max-content' }} />
          </div>
        )}
        {!previewMeta && <Empty description="请先上传并解析文件" />}
      </Modal>
          <div style={{ textAlign: 'right', marginTop: 12 }}>
            <Button onClick={() => setStep(0)} style={{ marginRight: 8 }}>← 上一步</Button>
              <Button type="primary" disabled={(() => {
                if (!uploadedFileId) return true;
                if (importMode === 'insert') return false;
                if (uniqueFields.length === 0) return true;
                if (uniqueFields.some(uf => !fieldMapping[uf] || fieldMapping[uf] === '__ignore__' || fieldMapping[uf] === '__custom__')) return true;
                return false;
              })()}
                onClick={async () => { await handlePreview(); setStep(2); }}>下一步 →</Button>
          </div>
            </div>
          )}
        </div>
      )}
      {step === 2 && (
        <div>
          <div style={{ fontWeight: 600, fontSize: 14, marginBottom: 16 }}>预览确认 — {selectedTable?.title || selectedTable?.name}</div>
          <Row gutter={12} style={{ marginBottom: 16 }}>
            <Col span={6}><Card size="small"><Statistic title="预计导入行数" value={previewData?.totalRows || 0} /></Card></Col>
            <Col span={6}><Card size="small"><Statistic title="错误行数" value={0} valueStyle={{ color: '#52c41a' }} /></Card></Col>
            <Col span={6}><Card size="small"><Statistic title="导入模式" value={importMode === 'insert' ? '新增' : importMode === 'update' ? '更新' : importMode === 'upsert' ? '新增+更新' : importMode} /></Card></Col>
            <Col span={6}><Card size="small"><Statistic title="Sheet名称" value={sheetName} /></Card></Col>
          </Row>
          <Card size="small" style={{ marginBottom: 16 }}>
            <Row gutter={12}>
              <Col span={12}><span style={{ color: '#666' }}>📄 上传文件：</span><Tag color="blue">{uploadedFileName}</Tag></Col>
              <Col span={12}><span style={{ color: '#666' }}>📋 表头行：</span><span>{headerRow}</span></Col>
            </Row>
            <div style={{ marginTop: 8 }}>
              <span style={{ color: '#666' }}>📊 目标工作表：</span>
              <Tag color="blue">{selectedTable?.title || selectedTable?.name} ({selectedTable?.name})</Tag>
            </div>
            {uniqueFields.length > 0 && (
              <div style={{ marginTop: 8 }}><span style={{ color: '#666' }}>🔑 唯一值字段：</span><Space wrap>{uniqueFields.map(f => <Tag key={f} color="orange">{f}</Tag>)}</Space></div>
            )}
            {Object.values(customValues).some(v => v) && (
              <div style={{ marginTop: 8 }}><span style={{ color: '#666' }}>✏️ 自定义固定值：</span><Space wrap>{Object.entries(customValues).filter(([, v]) => v).map(([k, v]) => (<Tag key={k} color="green">{k}: {v}</Tag>))}</Space></div>
            )}
          </Card>
          <div style={{ fontWeight: 600, marginBottom: 8 }}>👁️ 预览数据（前10行）</div>
          {previewData?.preview ? (
            <Table
              dataSource={previewData.preview.map((r: any, i: number) => {
                const row: any = { key: i };
                Object.entries(fieldMapping).forEach(([fieldName, excelCol]) => {
                  if (excelCol === '__custom__') {
                    row[fieldName] = customValues[fieldName] || '';
                  } else if (excelCol && excelCol !== '__ignore__') {
                    row[excelCol] = r[excelCol] !== undefined ? r[excelCol] : '';
                  }
                });
                return row;
              })}
              columns={(() => {
                const cols: any[] = [];
                const seen = new Set<string>();
                const titles: Record<string, string> = {};
                tableFields.forEach((f: any) => { titles[f.name] = f.uiSchema?.title || f.name; });
                Object.entries(fieldMapping).forEach(([fieldName, excelCol]) => {
                  const disp = titles[fieldName] || fieldName;
                  if (excelCol === '__custom__') {
                    cols.push({ title: '自定义-' + disp + '(' + fieldName + ')', dataIndex: fieldName });
                  } else if (excelCol && excelCol !== '__ignore__' && !seen.has(excelCol)) {
                    seen.add(excelCol);
                    cols.push({ title: excelCol + '-' + disp + '(' + fieldName + ')', dataIndex: excelCol });
                  }
                });
                return cols;
              })()}
              pagination={false} size="small" />
          ) : (
            <Empty description="暂无预览数据，请返回上一步上传文件" />
          )}
          <div style={{ textAlign: 'right', marginTop: 16 }}>
            <Button onClick={() => setStep(1)} style={{ marginRight: 8 }}>← 上一步</Button>
            <Button type="primary" onClick={handleExecute} disabled={!previewData}>▶ 执行导入</Button>
          </div>
        </div>
      )}
    </div>
  );
}
