import { Context, Next } from '@nocobase/actions';
import ExcelJS from 'exceljs';
import fs from 'fs';
import fsp from 'fs/promises';
import path from 'path';
import archiver from 'archiver';
import { Mutex } from 'async-mutex';
import { checkExportPermission } from './permission-check';
import { writeTaskLog } from './taskLogs';
import type { Database } from '@nocobase/database';

const exportMutex = new Mutex();

function sanitizeSheetName(name: string): string {
  return name.replace(/[\\\/\*\?\[\]:!@#\$%\^&\(\)]/g, '_').substring(0, 31);
}

function formatFileName(template: string, tableName: string): string {
  const d = new Date();
  const pad = (n: number) => String(n).padStart(2, '0');
  const date = `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`;
  return template.replace(/\{表名\}/g, tableName).replace(/\{日期\}/g, date);
}

function getFieldDisplayName(coll: any, fieldName: string, style?: string): string {
  try {
    const f = (coll.fields instanceof Map ? coll.fields.get(fieldName) : null);
    const title = f?.options?.uiSchema?.title;
    if (title && !/^\{\{/.test(title)) {
      if (style === 'id') return fieldName;
      if (style === 'title') return title;
      return `${title}(${fieldName})`;
    }
  } catch {}
  return fieldName;
}

function getCollDisplayName(coll: any, style?: string): string {
  const rawName = coll?.name || '';
  let title = coll?.options?.title || rawName;
  if (/^\{\{/.test(title)) title = rawName;
  if (style === 'id') return rawName;
  if (style === 'title') return title;
  return title !== rawName ? `${title}(${rawName})` : rawName;
}

function ensureUniqueSheetName(workbook: any, name: string): string {
  const existing = new Set((workbook.worksheets || []).map((s: any) => s.name));
  if (!existing.has(name)) return name;
  let i = 1;
  while (existing.has(`${name}_${i}`)) i++;
  return `${name}_${i}`;
}

function formatValue(val: any): string {
  if (val === null || val === undefined) return '';
  if (val instanceof Date) {
    const pad = (n: number) => String(n).padStart(2, '0');
    return `${val.getFullYear()}-${pad(val.getMonth() + 1)}-${pad(val.getDate())} ${pad(val.getHours())}:${pad(val.getMinutes())}:${pad(val.getSeconds())}`;
  }
  if (typeof val === 'object') return JSON.stringify(val);
  return String(val);
}

function getScalarFields(coll: any): string[] {
  if (!coll) return [];
  const names: string[] = [];
  try {
    for (const f of Array.from(coll.fields?.values() || coll.fields || [])) {
      const type = (f as any).type;
      if (!['belongsTo', 'hasOne', 'hasMany', 'belongsToMany'].includes(type)) {
        names.push((f as any).name);
      }
    }
  } catch {}
  return names;
}

function getAssociationFields(coll: any): Array<{ name: string; type: string; target: string }> {
  if (!coll) return [];
  const fields: Array<{ name: string; type: string; target: string }> = [];
  try {
    for (const f of Array.from(coll.fields?.values() || coll.fields || [])) {
      const type = (f as any).type;
      if (['belongsTo', 'hasOne', 'hasMany', 'belongsToMany'].includes(type)) {
        fields.push({
          name: (f as any).name,
          type,
          target: (f as any).options?.target || (f as any).target || '',
        });
      }
    }
  } catch {}
  return fields;
}

export async function getExportTableFields(ctx: Context, next: Next) {
  const { tableName } = ctx.action.params;
  if (!tableName || tableName === '__all__') {
    ctx.body = [];
    await next();
    return;
  }
  const coll: any = ctx.db.getCollection(tableName);
  if (!coll) {
    ctx.throw(404, `Table ${tableName} not found`);
  }
  let rawFields: any[] = [];
  try {
    rawFields = Array.from(coll.fields?.values() || coll.fields || []);
  } catch {
    rawFields = [];
  }
  const autoFields = ['id', 'createdAt', 'updatedAt', 'createdBy', 'updatedBy', 'createdById', 'updatedById'];
  const fkSet = new Set<string>();
  rawFields.forEach((f: any) => {
    if (f.type === 'belongsTo' && f.options?.foreignKey) {
      fkSet.add(f.options.foreignKey);
    }
  });
  const fields = rawFields.map((f: any) => {
    let title = f.options?.uiSchema?.title || null;
    if (title && /^\{\{/.test(title)) title = null;
    if (!title) title = f.name;
    return {
      name: f.name,
      type: f.type,
      uiSchema: { ...(f.options?.uiSchema || {}), title },
      interface: f.options?.interface || null,
      isRequired: autoFields.includes(f.name) ? false : f.options?.allowNull === false,
      isAssociation: ['belongsTo', 'hasOne', 'hasMany', 'belongsToMany'].includes(f.type),
      isForeignKey: fkSet.has(f.name),
    };
  });
  ctx.body = fields;
  await next();
}

export async function previewCount(ctx: Context, next: Next) {
  const params = ctx.action.params.values || ctx.action.params;
  const { tableName, filter } = params;
  if (!tableName || tableName === '__all__') {
    let total = 0;
    const collections = ctx.db.collections;
    for (const [name, coll] of collections) {
      try {
        const repo = ctx.db.getRepository(name);
        if (repo) total += await repo.count({ filter: filter || {} });
      } catch {}
    }
    ctx.body = { estimatedRows: total };
    await next();
    return;
  }
  const repo = ctx.db.getRepository(tableName);
  const count = repo ? await repo.count({ filter: filter || {} }) : 0;
  ctx.body = { estimatedRows: count };
  await next();
}

export async function executeExport(ctx: Context, next: Next) {
  const params = ctx.action.params.values || ctx.action.params;
  const {
    tableName, selectedFields, associationDisplayMode, includeAssociationSheet,
    associationSheetTables, filter, fileNameTemplate, includeAttachments, headerStyle,
  } = params;

  const exportFilter = (() => {
    if (!filter) return {};
    if (Array.isArray(filter)) {
      const obj: Record<string, any> = {};
      for (const cond of filter) {
        if (cond.field && cond.op && cond.value !== undefined) {
          const opMap: Record<string, string> = { eq: '$eq', contains: '$includes', gt: '$gt', lt: '$lt' };
          obj[cond.field] = { [opMap[cond.op] || '$eq']: cond.value };
        }
      }
      return obj;
    }
    return filter;
  })();

  if (!tableName) {
    ctx.throw(400, 'tableName is required');
  }

  if (tableName !== '__all__') {
    const exportPerm = await checkExportPermission(ctx, tableName);
    if (exportPerm.exportFields && exportPerm.exportFields.length > 0 && selectedFields && selectedFields.length > 0) {
      const invalidFields = selectedFields.filter((f: string) => !exportPerm.exportFields.includes(f));
      if (invalidFields.length > 0) {
        ctx.throw(403, `您的权限不允许导出以下字段：${invalidFields.join('、')}，请联系管理员`);
      }
    }
  }

  let allowedTableList: string[] | null = null;
  if (tableName === '__all__') {
    const names: string[] = [];
    const collections = ctx.db.collections;
    for (const [name] of collections) {
      try {
        const permCheck = await checkExportPermission(ctx, name);
        if (permCheck.canExport) names.push(name);
      } catch { }
    }
    allowedTableList = names;
  }

  const repo = ctx.db.getRepository('sjgl02_tasks');
  const task = await repo.create({
    values: {
      taskType: 'export',
      tableName,
      status: 'pending',
      selectedFields: selectedFields || [],
      exportFilter: exportFilter || {},
      associationDisplayMode: associationDisplayMode || {},
      includeAssociationSheet: includeAssociationSheet || false,
      associationSheetTables: associationSheetTables || [],
      includeAttachments: includeAttachments || false,
      totalRows: 0,
      progress: 0,
      fileName: tableName === '__all__' ? `全部数据表_${new Date().toISOString().slice(0, 10)}.zip` : '',
      createdById: ctx.state.currentUser?.id,
      headerStyle: headerStyle || 'title_id',
    },
  });

  const db = ctx.db;
  const taskId = task.id;

  ctx.body = { taskId };
  await next();

  setImmediate(() => {
    processExportAsync(db, taskId, {
      tableName, selectedFields, associationDisplayMode, includeAssociationSheet,
      associationSheetTables, exportFilter, fileNameTemplate, includeAttachments, headerStyle,
      allowedTableList,
    });
  });
}

interface ExportAsyncParams {
  tableName: string;
  selectedFields?: string[];
  associationDisplayMode?: Record<string, string>;
  includeAssociationSheet?: boolean;
  associationSheetTables?: string[];
  exportFilter?: Record<string, any>;
  fileNameTemplate?: string;
  includeAttachments?: boolean;
  headerStyle?: string;
  allowedTableList: string[] | null;
}

async function processExportAsync(db: Database, taskId: number, params: ExportAsyncParams) {
  const {
    tableName, selectedFields, associationDisplayMode, includeAssociationSheet,
    associationSheetTables, exportFilter, fileNameTemplate, includeAttachments, headerStyle,
    allowedTableList,
  } = params;

  const repo = db.getRepository('sjgl02_tasks');

  const release = await exportMutex.acquire();

  try {
    await repo.update({ filterByTk: taskId, values: { status: 'processing' } });

    await writeTaskLog(db, taskId, 'INFO', '开始执行导出任务');
    await writeTaskLog(db, taskId, 'INFO', `目标数据表: ${tableName}${tableName === '__all__' ? '（全部数据表）' : ''}`);

    const isAllTables = tableName === '__all__';
    const tableList: string[] = isAllTables
      ? (allowedTableList || [])
      : [tableName];

    const tempDir = path.join(process.env.LOCAL_STORAGE_BASE_URL || process.env.STORAGE_DIR || 'storage/uploads', 'exports');
    if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });

    let totalRows = 0;
    let processedRows = 0;
    const outputFiles: string[] = [];

    for (const tblName of tableList) {
      const coll: any = db.getCollection(tblName);
      if (!coll) continue;
      const targetRepo = db.getRepository(tblName);
      if (!targetRepo) continue;

      let records: any[] = [];
      let collectionTotal = 0;
      const appendFields: string[] = [];
      const attachmentFieldNames: string[] = [];
      const fileIdFieldNames: string[] = [];
      try {
        for (const f of Array.from(coll.fields?.values() || coll.fields || [])) {
          if ((f as any).type === 'belongsTo') appendFields.push((f as any).name);
          if (includeAttachments && ((f as any).type === 'belongsToMany')) {
            const interfaceName = (f as any).options?.interface;
            if (interfaceName === 'attachment' && !appendFields.includes((f as any).name)) {
              appendFields.push((f as any).name);
              attachmentFieldNames.push((f as any).name);
            }
          }
          if (includeAttachments && ((f as any).type === 'integer') && /FileId$/.test((f as any).name)) {
            fileIdFieldNames.push((f as any).name);
          }
        }
      } catch {}
      try { const [,c] = await targetRepo.findAndCount({ filter: exportFilter || {}, limit: 1 }); collectionTotal = c; } catch {}
      if (collectionTotal === 0) continue;

      const fieldNames: string[] = (selectedFields && selectedFields.length > 0)
        ? selectedFields
        : getScalarFields(coll);
      if (!fieldNames || fieldNames.length === 0) continue;

      const collDisplay = sanitizeSheetName(getCollDisplayName(coll, headerStyle)).replace(/\s+/g, '_');
      const xlsxName = collDisplay + '-' + formatFileName('{日期}.xlsx', '');
      const filePath = path.join(tempDir, xlsxName);

      const streamWriter = new ExcelJS.stream.xlsx.WorkbookWriter({
        filename: filePath, useStyles: true, useSharedStrings: true,
      });
      streamWriter.creator = 'NocoBase @my-project/plugin-sjgl02';
      const mainSheet = streamWriter.addWorksheet(
        ensureUniqueSheetName(streamWriter as any, sanitizeSheetName(getCollDisplayName(coll, headerStyle)))
      );
      mainSheet.columns = fieldNames.map((name: string) => ({
        header: getFieldDisplayName(coll, name, headerStyle), key: name,
        width: Math.max(getFieldDisplayName(coll, name, headerStyle).length + 4, 20),
      }));
      (mainSheet.getRow(1) as any).font = { bold: true };
      (mainSheet.getRow(1) as any).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE0E0E0' } };

      const PAGE_SIZE = 5000;
      let offset = 0;

      while (offset < collectionTotal) {
        const pageRecords = await targetRepo.find({
          filter: exportFilter || {}, offset, limit: PAGE_SIZE,
          ...(appendFields.length > 0 ? { appends: appendFields } : {}),
        });
        if (pageRecords.length === 0) break;

        for (const record of pageRecords) {
          const row: Record<string, any> = {};
          for (const f of fieldNames) {
            let val = record[f];
            if (attachmentFieldNames.includes(f)) {
              if (Array.isArray(val) && val.length > 0) {
                val = val.map((a: any) => a.filename || a.title || a.id || '').join(', ');
              } else val = '';
            } else if (fileIdFieldNames.includes(f)) {
              val = val !== null && val !== undefined ? String(val) : '';
            } else if (val !== null && val !== undefined && typeof val === 'object' && !(val instanceof Date)) {
              val = val.nickname || val.username || val.name || val.email || val.id || JSON.stringify(val);
            }
            row[f] = formatValue(val);
          }
          mainSheet.addRow(row).commit();
          processedRows++;
          totalRows++;
        }
        offset += PAGE_SIZE;
        const progress = Math.min(100, Math.floor((offset * 100) / Math.max(1, collectionTotal)));
        try { await repo.update({ filterByTk: taskId, values: { processedRows, totalRows, progress } }); } catch {}
      }

      if (includeAssociationSheet) {
        const assocFields = getAssociationFields(coll);
        for (const af of assocFields.filter((af: any) => !fieldNames.length || fieldNames.includes(af.name))) {
          const assocRepo = db.getRepository(af.target);
          if (!assocRepo) continue;
          let assocTotal = 0;
          try { const [,cnt] = await assocRepo.findAndCount({ limit:1 }); assocTotal = cnt; } catch {}
          if (assocTotal === 0) continue;
          const assocColl = db.getCollection(af.target);
          const assocScalarFields = getScalarFields(assocColl);
          if (!assocScalarFields || assocScalarFields.length === 0) continue;

          const fieldDisplay = getFieldDisplayName(coll, af.name, headerStyle);
          const sheetDisplay = getCollDisplayName(assocColl, headerStyle);
          const sheetName = ensureUniqueSheetName(streamWriter as any, sanitizeSheetName(fieldDisplay + '-' + sheetDisplay).substring(0,31));
          const assocSheet = streamWriter.addWorksheet(sheetName);
          assocSheet.columns = assocScalarFields.map((n: string) => ({
            header: getFieldDisplayName(assocColl, n, headerStyle), key: n,
            width: Math.max(getFieldDisplayName(assocColl, n, headerStyle).length + 4, 20),
          }));
          (assocSheet.getRow(1) as any).font = { bold: true };
          (assocSheet.getRow(1) as any).fill = { type:'pattern',pattern:'solid',fgColor:{argb:'FFF5F5F5'}};

          let aOff = 0;
          while (aOff < assocTotal) {
            const aRecs = await assocRepo.find({ offset: aOff, limit: PAGE_SIZE });
            for (const rec of aRecs) {
              const row: Record<string, any> = {};
              for (const f of assocScalarFields) {
                let val = rec[f];
                if (val !== null && val !== undefined && typeof val === 'object' && !(val instanceof Date))
                  val = (val.nickname || val.title || val.name || val.id || JSON.stringify(val));
                row[f] = formatValue(val);
              }
              assocSheet.addRow(row).commit();
              totalRows++; processedRows++;
            }
            aOff += PAGE_SIZE;
            const ap = Math.min(100, Math.floor((aOff * 100) / Math.max(1, assocTotal)));
            try { await repo.update({ filterByTk: taskId, values: { processedRows, totalRows, progress: Math.max(ap, 0) } }); } catch {}
          }
          assocSheet.commit();
        }
      }

      mainSheet.commit();
      await streamWriter.commit();
      outputFiles.push(filePath);

      if (includeAttachments && (attachmentFieldNames.length > 0 || fileIdFieldNames.length > 0)) {
        const attachIds = new Set<number>();
        const attachFieldMap = new Map<number, string>();
        let aScanOff = 0;
        while (aScanOff < collectionTotal) {
          const pr = await targetRepo.find({
            filter: exportFilter || {}, offset: aScanOff, limit: PAGE_SIZE,
            ...(appendFields.length > 0 ? { appends: appendFields } : {}),
          });
          for (const r of pr) {
            for (const an of attachmentFieldNames) {
              if (Array.isArray(r[an])) for (const a of r[an]) if (a?.id && !attachIds.has(a.id)) { attachIds.add(a.id); attachFieldMap.set(a.id, an); }
            }
            for (const fn of fileIdFieldNames) {
              const fid = r[fn]; if (fid && !attachIds.has(fid)) { attachIds.add(fid); attachFieldMap.set(fid, fn); }
            }
          }
          aScanOff += PAGE_SIZE;
        }
        if (attachIds.size > 0) {
          const fileIdFilenameMap = new Map<number, string>();
          try {
            const ar = await db.getRepository('attachments').find({ filter: { id: Array.from(attachIds) } });
            ar.forEach((at: any) => { if (at.filename) fileIdFilenameMap.set(at.id, at.filename); });
          } catch {}
          if (fileIdFilenameMap.size > 0) {
            try {
              const storageDir = process.env.LOCAL_STORAGE_BASE_URL || process.env.STORAGE_DIR || 'storage/uploads';
              const attachmentFiles: Array<{ entryName: string; diskPath: string }> = [];
              for (const [aid, fn] of fileIdFilenameMap) {
                const diskPath = path.join(storageDir, fn);
                let realPath = diskPath;
                if (!fs.existsSync(realPath)) {
                  const atRecords = await db.getRepository('attachments').find({ filter: { id: [aid] } });
                  if (atRecords[0]?.path !== undefined) {
                    realPath = path.join(storageDir, atRecords[0].path || '', fn);
                  }
                }
                if (!fs.existsSync(realPath)) continue;
                const afName = attachFieldMap.get(aid) || '附件';
                const folderName = sanitizeSheetName(getFieldDisplayName(coll, afName, headerStyle));
                attachmentFiles.push({ entryName: `${folderName}/${fn}`, diskPath: realPath });
              }
              if (attachmentFiles.length > 0) {
                const zipName = collDisplay + '-' + formatFileName('{日期}.zip', '');
                const zipPath = path.join(tempDir, zipName);
                const zipOutput = fs.createWriteStream(zipPath);
                const zipArchive = archiver('zip', { zlib: { level: 9 } });
                await new Promise<void>((resolve, reject) => {
                  zipArchive.on('error', reject);
                  zipOutput.on('close', resolve);
                  zipArchive.pipe(zipOutput);
                  zipArchive.file(filePath, { name: path.basename(filePath) });
                  for (const af of attachmentFiles) {
                    zipArchive.file(af.diskPath, { name: af.entryName });
                  }
                  zipArchive.finalize();
                });
                try { fs.unlinkSync(filePath); } catch {}
                outputFiles[outputFiles.indexOf(filePath)] = zipPath;
              }
            } catch {}
          }
        }
      }

      await repo.update({
        filterByTk: taskId,
        values: { progress: Math.min(100, Math.floor((processedRows / Math.max(totalRows, 1)) * 100)), processedRows, totalRows },
      });
    }

    let finalFilePath: string;
    if (outputFiles.length === 0) {
      throw new Error('没有数据可导出');
    } else if (outputFiles.length === 1) {
      finalFilePath = outputFiles[0];
    } else {
      const zipName = '全部数据表-' + formatFileName('{日期}.zip', '');
      finalFilePath = path.join(tempDir, zipName);
      const output = fs.createWriteStream(finalFilePath);
      const archive = archiver('zip', { zlib: { level: 9 } });
      await new Promise<void>((resolve, reject) => {
        try {
          output.on('close', resolve);
          archive.on('error', reject);
          archive.pipe(output);
          for (const fp of outputFiles) {
            archive.file(fp, { name: path.basename(fp) });
          }
          archive.finalize();
        } catch (err) {
          reject(err);
        }
      });
      for (const fp of outputFiles) {
        try { fs.unlinkSync(fp); } catch {}
      }
    }

    const stats = await fsp.stat(finalFilePath);
    const attachRepo = db.getRepository('attachments');
    const exportAttachment = await attachRepo.create({
      values: {
        title: path.basename(finalFilePath),
        filename: path.basename(finalFilePath),
        extname: path.extname(finalFilePath),
        mimetype: finalFilePath.endsWith('.zip')
          ? 'application/zip'
          : 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        size: stats.size,
        path: path.relative(process.env.LOCAL_STORAGE_BASE_URL || process.env.STORAGE_DIR || 'storage/uploads', finalFilePath).replace(/\\/g, '/'),
      },
    });

    await repo.update({
      filterByTk: taskId,
      values: {
        status: 'completed',
        progress: 100,
        processedRows,
        totalRows,
        exportFileId: exportAttachment.id,
        fileName: exportAttachment.filename || exportAttachment.title || '',
        completedAt: new Date(),
      },
    });
    await writeTaskLog(db, taskId, 'SUCC', `导出完成，共 ${processedRows} 行数据`);
  } catch (err: any) {
    try {
      await writeTaskLog(db, taskId, 'ERROR', `导出失败: ${err.message || String(err)}`);
      await writeTaskLog(db, taskId, 'WARN', '文件未生成，数据未修改');
      await repo.update({
        filterByTk: taskId,
        values: {
          status: 'failed',
          errorMessage: err.message || String(err),
          completedAt: new Date(),
        },
      });
    } catch {}
  } finally {
    release();
  }
}

export async function getProgress(ctx: Context, next: Next) {
  const { taskId } = ctx.action.params;
  const repo = ctx.db.getRepository('sjgl02_tasks');
  const task = await repo.findOne({ filter: { id: taskId } });
  if (!task) {
    ctx.throw(404, 'Task not found');
  }
  ctx.body = {
    progress: task.progress,
    status: task.status,
    exportFileId: task.exportFileId,
  };
  await next();
}

export async function downloadExport(ctx: Context, next: Next) {
  const { taskId } = ctx.action.params;
  const repo = ctx.db.getRepository('sjgl02_tasks');
  const task = await repo.findOne({ filter: { id: taskId } });
  if (!task) {
    ctx.throw(404, 'Task not found');
  }
  if (!task.exportFileId) {
    ctx.throw(404, 'Export file not found');
  }
  const attachRepo = ctx.db.getRepository('attachments');
  const attachment = await attachRepo.findOne({ filter: { id: task.exportFileId } });
  if (!attachment) {
    ctx.throw(404, 'Attachment record not found');
  }
  const storageDir = process.env.LOCAL_STORAGE_BASE_URL || process.env.STORAGE_DIR || 'storage/uploads';
  const filePath = path.join(storageDir, attachment.path || attachment.filename);
  if (!fs.existsSync(filePath)) {
    ctx.throw(404, 'File not found on disk');
  }
  const fileName = attachment.title || attachment.filename || 'export.xlsx';
  ctx.attachment(encodeURIComponent(fileName));
  ctx.set('Content-Type', attachment.mimetype || 'application/octet-stream');
  ctx.body = fs.createReadStream(filePath);
  await next();
}
