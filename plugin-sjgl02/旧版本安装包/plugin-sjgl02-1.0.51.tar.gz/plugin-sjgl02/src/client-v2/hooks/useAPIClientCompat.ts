import { useMemo } from 'react';
import { useApp } from '@nocobase/client-v2';

export function useAPIClient() {
  const app = useApp();
  return useMemo(() => {
    return (app as any).apiClient || app || {
      request: () => Promise.reject(new Error('API Client not available')),
    };
  }, [app]);
}
