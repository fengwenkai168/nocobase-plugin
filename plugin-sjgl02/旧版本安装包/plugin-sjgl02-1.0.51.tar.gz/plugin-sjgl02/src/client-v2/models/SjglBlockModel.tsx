import React from 'react';
import { DatabaseOutlined } from '@ant-design/icons';
import { BlockModel } from '@nocobase/client-v2';

export class SjglBlockModel extends BlockModel {
  renderComponent() {
    return (
      <div style={{ padding: 16 }}>
        <div style={{ background: 'linear-gradient(135deg,#1677ff,#0958d9)', borderRadius: 10, padding: '10px 20px', color: '#fff', marginBottom: 12, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ fontWeight: 600, fontSize: 16 }}>📊 数据管理</div>
          <div style={{ opacity: 0.7, fontSize: 11 }}>@my-project/plugin-sjgl02</div>
        </div>
      </div>
    );
  }
}

SjglBlockModel.define({
  label: '数据管理',
  icon: React.createElement(DatabaseOutlined),
});
