import { test, expect } from '../test';
import { SETTINGS_URL, TEST_TABLE, ensurePluginEnabled, clearProducts, clearTasks, seedProducts, uploadFileToAttachments, executeImport, waitForTask, getRecords, fixturePath } from '../helpers/sjgl02-helpers';
import { setupE2EEnvironment, cleanupE2EEnvironment } from '../helpers/admin-api';

async function adminImport(page: any, adminApi: any, fileName: string, mode = 'insert', uniqueFields: string[] = []) {
  await page.goto(SETTINGS_URL);
  await page.getByRole('tab', { name: /导入/ }).click();
  await expect(page.getByTestId('import-table-select')).toBeVisible();

  const fileId = await uploadFileToAttachments(adminApi, fileName);
  const parseRes = await adminApi.post('/api/sjgl02Import:uploadParse', {
    data: { fileId, sheetName: 'Sheet1', headerRow: 1 },
  });
  const parseData = await parseRes.json();
  const excelHeaders = parseData.data?.headerColumns || [];
  const fieldMapping: Record<string, string> = {};
  for (const h of excelHeaders) {
    fieldMapping[h] = h;
  }

  const taskId = await executeImport(adminApi, {
    tableName: TEST_TABLE,
    fileId,
    sheetName: 'Sheet1',
    headerRow: 1,
    fieldMapping,
    customValues: {},
    importMode: mode,
    uniqueFields,
    blankCellMode: 'update',
    permSource: null,
  });
  return { taskId, fileId };
}

test.describe('管理员 update 导入', () => {
  test.beforeEach(async ({ page, adminApi }) => {
    await setupE2EEnvironment(adminApi);
    await ensurePluginEnabled(page);
    await clearProducts(adminApi);
    await clearTasks(adminApi);
  });

  test.afterEach(async ({ adminApi }) => {
    await clearProducts(adminApi);
    await clearTasks(adminApi);
    await cleanupE2EEnvironment(adminApi);
  });

  test('管理员 update 导入更新价格', async ({ page, adminApi }) => {
    await seedProducts(adminApi, [
      { name: '商品A', code: 'A001', price: 10 },
      { name: '商品B', code: 'A002', price: 20 },
    ]);

    const { taskId } = await adminImport(page, adminApi, 'admin-update.xlsx', 'update', ['code']);
    const task = await waitForTask(adminApi, taskId);
    expect(task.status).toBe('completed');

    const records = await getRecords(adminApi);
    const recordA = records.find((r) => r.code === 'A001');
    const recordB = records.find((r) => r.code === 'A002');
    expect(recordA).toBeDefined();
    expect(recordB).toBeDefined();
    expect(recordA.price).toBe(99);
    expect(recordB.price).toBe(199);
  });
});
