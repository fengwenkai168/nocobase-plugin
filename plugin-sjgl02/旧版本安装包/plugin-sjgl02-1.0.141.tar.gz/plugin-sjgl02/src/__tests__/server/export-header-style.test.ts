import { setupTestApp, teardownTestApp, createProductCollection, saveTablePermission } from './helpers/setup';
import { cleanupBusinessData, cleanupTargetTable, cleanupShadowTables } from './helpers/cleanup';
import { MockServer } from '@nocobase/test';
import ExcelJS from 'exceljs';

async function waitForTask(app: MockServer, taskId: number, timeout = 30000): Promise<any> {
  const start = Date.now();
  while (Date.now() - start < timeout) {
    const task = await app.db.getRepository('sjgl02_tasks').findOne({ filter: { id: taskId } });
    if (['completed', 'failed', 'cancelled'].includes(task.get('status'))) {
      return task;
    }
    await new Promise((resolve) => setTimeout(resolve, 500));
  }
  throw new Error('等待任务完成超时');
}

async function downloadExport(api: any, taskId: number): Promise<Buffer> {
  const res = await api.resource('sjgl02Export').download({ filter: { taskId } });
  return res.body;
}

describe('Export Header Style', () => {
  let ctx: { app: MockServer; adminAgent: any };

  beforeEach(async () => {
    ctx = await setupTestApp();
    await createProductCollection(ctx.app);

    await ctx.app.db.getRepository('sjgl02_e2e_products').create({
      values: { name: 'Apple', code: 'A001', sku: 1001, price: 10.5, stock: 100 },
    });

    await saveTablePermission(ctx.app, ctx.adminAgent, {
      targetType: 'role',
      targetId: 'member',
      targetName: 'member',
      tableName: 'sjgl02_e2e_products',
      canImport: false,
      canExport: true,
      exportFields: ['name', 'price', 'stock'],
    });
  });

  afterEach(async () => {
    await cleanupShadowTables(ctx.app);
    await cleanupTargetTable(ctx.app, 'sjgl02_e2e_products');
    await cleanupBusinessData(ctx.app);
    await teardownTestApp(ctx.app);
  });

  it('title_id 格式导出表头为"字段名(字段标识)"', async () => {
    const res = await ctx.adminAgent.resource('sjgl02Export').execute({
      values: {
        tableName: 'sjgl02_e2e_products',
        selectedFields: ['name', 'price'],
        headerStyle: 'title_id',
      },
    });

    const task = await waitForTask(ctx.app, res.body.data.taskId);
    const buffer = await downloadExport(ctx.adminAgent, task.get('id'));

    const wb = new ExcelJS.Workbook();
    await wb.xlsx.load(buffer);
    const ws = wb.worksheets[0];
    const headers = ws.getRow(1).values.slice(1) as string[];

    expect(headers).toContain('商品名称(name)');
    expect(headers).toContain('价格(price)');
  });

  it('title 格式导出表头为"字段名"', async () => {
    const res = await ctx.adminAgent.resource('sjgl02Export').execute({
      values: {
        tableName: 'sjgl02_e2e_products',
        selectedFields: ['name', 'price'],
        headerStyle: 'title',
      },
    });

    const task = await waitForTask(ctx.app, res.body.data.taskId);
    const buffer = await downloadExport(ctx.adminAgent, task.get('id'));

    const wb = new ExcelJS.Workbook();
    await wb.xlsx.load(buffer);
    const ws = wb.worksheets[0];
    const headers = ws.getRow(1).values.slice(1) as string[];

    expect(headers).toContain('商品名称');
    expect(headers).toContain('价格');
  });

  it('id 格式导出表头为"字段标识"', async () => {
    const res = await ctx.adminAgent.resource('sjgl02Export').execute({
      values: {
        tableName: 'sjgl02_e2e_products',
        selectedFields: ['name', 'price'],
        headerStyle: 'id',
      },
    });

    const task = await waitForTask(ctx.app, res.body.data.taskId);
    const buffer = await downloadExport(ctx.adminAgent, task.get('id'));

    const wb = new ExcelJS.Workbook();
    await wb.xlsx.load(buffer);
    const ws = wb.worksheets[0];
    const headers = ws.getRow(1).values.slice(1) as string[];

    expect(headers).toContain('name');
    expect(headers).toContain('price');
  });
});
