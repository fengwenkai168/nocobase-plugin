import { setupTestApp, teardownTestApp, createTestCollections, saveTablePermission } from './helpers/setup';
import { cleanupBusinessData, cleanupTargetTable, cleanupShadowTables } from './helpers/cleanup';
import { MockServer } from '@nocobase/test';
import ExcelJS from 'exceljs';
import * as fs from 'fs';
import * as path from 'path';

async function waitForTask(app: MockServer, taskId: number, timeout = 30000): Promise<any> {
  const start = Date.now();
  while (Date.now() - start < timeout) {
    const task = await app.db.getRepository('sjgl02_tasks').findOne({ filter: { id: taskId } });
    if (['completed', 'failed', 'cancelled'].includes(task.get('status'))) {
      return task;
    }
    await new Promise((resolve) => setTimeout(resolve, 500));
  }
  throw new Error('等待任务完成超时');
}

async function readExportBuffer(app: MockServer, task: any): Promise<Buffer> {
  const exportFileId = task.get('exportFileId');
  if (!exportFileId) {
    throw new Error('导出任务未生成文件');
  }
  const attachment = await app.db.getRepository('attachments').findOne({
    filter: { id: exportFileId },
  });
  if (!attachment) {
    throw new Error('导出文件附件记录不存在');
  }
  const storageDir = process.env.LOCAL_STORAGE_BASE_URL || process.env.STORAGE_DIR || 'storage/uploads';
  const filePath = path.join(storageDir, attachment.get('path') || attachment.get('filename'));
  return fs.readFileSync(filePath);
}

describe('Export Association Sheet', () => {
  let ctx: { app: MockServer; adminAgent: any; adminUser: any };

  beforeEach(async () => {
    ctx = await setupTestApp();
    await createTestCollections(ctx.app);

    await ctx.app.db.getRepository('posts').create({
      values: {
        title: '文章1',
        content: '内容1',
        views: 10,
        author: { id: ctx.adminUser.get('id') },
      },
    });

    await saveTablePermission(ctx.app, ctx.adminAgent, {
      targetType: 'role',
      targetId: 'member',
      targetName: 'member',
      tableName: 'posts',
      canImport: false,
      canExport: true,
      exportFields: ['title', 'content', 'views'],
    });
  });

  afterEach(async () => {
    await cleanupShadowTables(ctx.app);
    await cleanupTargetTable(ctx.app, 'posts');
    await cleanupBusinessData(ctx.app);
    await teardownTestApp(ctx.app);
  });

  it('includeAssociationSheet=true 时导出文件包含关联表 sheet', async () => {
    const res = await ctx.adminAgent.resource('sjgl02Export').execute({
      values: {
        tableName: 'posts',
        selectedFields: ['title', 'content', 'views', 'author'],
        includeAssociationSheet: true,
      },
    });

    expect(res.status).toBe(200);
    const task = await waitForTask(ctx.app, res.body.data.taskId);
    expect(task.get('status')).toBe('completed');

    const buffer = await readExportBuffer(ctx.app, task);
    const wb = new ExcelJS.Workbook();
    await wb.xlsx.load(buffer);

    expect(wb.worksheets.length).toBeGreaterThan(1);
    const sheetNames = wb.worksheets.map((ws) => ws.name);
    expect(sheetNames.some((name) => name.toLowerCase().includes('users'))).toBe(true);
  });

  it('includeAssociationSheet=false 时只导出主表 sheet', async () => {
    const res = await ctx.adminAgent.resource('sjgl02Export').execute({
      values: {
        tableName: 'posts',
        selectedFields: ['title', 'content', 'views', 'author'],
        includeAssociationSheet: false,
      },
    });

    const task = await waitForTask(ctx.app, res.body.data.taskId);
    expect(task.get('status')).toBe('completed');

    const buffer = await readExportBuffer(ctx.app, task);
    const wb = new ExcelJS.Workbook();
    await wb.xlsx.load(buffer);

    expect(wb.worksheets.length).toBe(1);
  });
});
