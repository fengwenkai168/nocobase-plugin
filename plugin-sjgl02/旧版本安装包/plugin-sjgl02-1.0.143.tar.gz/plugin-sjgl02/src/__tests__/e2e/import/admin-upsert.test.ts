import { test, expect } from '../test';
import {
  SETTINGS_URL,
  TEST_TABLE,
  ensurePluginEnabled,
  clearProducts,
  clearTasks,
  seedProducts,
  uploadFileToAttachments,
  executeImport,
  waitForTask,
  getRecords,
  getRecordCount,
  fixturePath,
} from '../helpers/sjgl02-helpers';
import { setupE2EEnvironment, cleanupE2EEnvironment } from '../helpers/admin-api';

async function adminImport(page: any, adminApi: any, fileName: string, mode = 'insert', uniqueFields: string[] = []) {
  await page.goto(SETTINGS_URL);
  await page.getByRole('tab', { name: /导入/ }).click();
  await expect(page.getByTestId('import-table-select')).toBeVisible();

  const fileId = await uploadFileToAttachments(adminApi, fileName);
  const parseRes = await adminApi.post('/api/sjgl02Import:uploadParse', {
    data: { fileId, sheetName: 'Sheet1', headerRow: 1 },
  });
  const parseData = await parseRes.json();
  const excelHeaders = parseData.data?.headerColumns || [];
  const fieldMapping: Record<string, string> = {};
  for (const h of excelHeaders) {
    fieldMapping[h] = h;
  }

  const taskId = await executeImport(adminApi, {
    tableName: TEST_TABLE,
    fileId,
    sheetName: 'Sheet1',
    headerRow: 1,
    fieldMapping,
    customValues: {},
    importMode: mode,
    uniqueFields,
    blankCellMode: 'update',
    permSource: null,
  });
  return { taskId, fileId };
}

test.describe('管理员 upsert 导入', () => {
  test.beforeEach(async ({ page, adminApi }) => {
    await setupE2EEnvironment(adminApi);
    await ensurePluginEnabled(page);
    await clearProducts(adminApi);
    await clearTasks(adminApi);
  });

  test.afterEach(async ({ adminApi }) => {
    await clearProducts(adminApi);
    await clearTasks(adminApi);
    await cleanupE2EEnvironment(adminApi);
  });

  test('管理员 upsert 导入 1 更新 + 1 新增', async ({ page, adminApi }) => {
    await seedProducts(adminApi, [{ name: '旧商品', code: 'A001', price: 10 }]);

    const { taskId } = await adminImport(page, adminApi, 'admin-upsert.xlsx', 'upsert', ['code']);
    const task = await waitForTask(adminApi, taskId);
    expect(task.status).toBe('completed');

    const count = await getRecordCount(adminApi);
    expect(count).toBe(2);

    const records = await getRecords(adminApi);
    const updated = records.find((r) => r.code === 'A001');
    const created = records.find((r) => r.code === 'A002');
    expect(updated).toBeDefined();
    expect(created).toBeDefined();
    expect(updated.price).toBe(88);
    expect(created.name).toBe('新商品');
  });
});
