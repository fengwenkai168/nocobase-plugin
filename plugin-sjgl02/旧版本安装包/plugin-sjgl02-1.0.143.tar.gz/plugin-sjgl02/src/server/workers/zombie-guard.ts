import { ChildProcess, fork } from 'child_process';
import path from 'path';
import type { Database } from '@nocobase/database';
import type { StartMessage, WorkerMessage } from './types';

const HEARTBEAT_TIMEOUT = 120000; // 子进程 2 分钟无心跳 → 杀
const SIGTERM_GRACE = 10000; // SIGTERM 后等 10 秒再 SIGKILL
const SCAN_INTERVAL = 30000; // 调度器每 30 秒扫描一次
const MAX_TASK_DURATION = 30 * 60 * 1000; // 导入总超时 30 分钟

/** 活跃的导出子进程：taskId → ChildProcess */
export const activeWorkers = new Map<number, ChildProcess>();
/** 导入任务的启动时间：taskId → Date.now() */
export const importTimers = new Map<number, number>();

/** 获取编译后的 worker 入口路径 */
function getWorkerPath(): string {
  return path.join(__dirname, '..', 'workers', 'export-worker.js');
}

/** 杀掉一个子进程（优雅退出 → 强制杀） */
function killWorker(child: ChildProcess): void {
  if (child.killed || child.exitCode !== null) return;
  try {
    child.kill('SIGTERM');
    setTimeout(() => {
      if (!child.killed && child.exitCode === null) {
        child.kill('SIGKILL');
      }
    }, SIGTERM_GRACE);
  } catch {
    /* 忽略 */
  }
}

/** fork 导出子进程，设置心跳和总超时监控 */
export function forkExportWorker(taskId: number, startMsg: StartMessage, repo: any): ChildProcess {
  const workerPath = getWorkerPath();
  const child = fork(workerPath, [], { silent: true });

  activeWorkers.set(taskId, child);

  let lastHeartbeat = Date.now();
  let resolved = false;

  const heartbeatTimer = setInterval(() => {
    if (resolved) return;
    const elapsed = Date.now() - lastHeartbeat;
    if (elapsed > HEARTBEAT_TIMEOUT) {
      killWorker(child);
    }
  }, 30000);

  const maxDurationTimer = setTimeout(() => {
    if (!resolved) {
      killWorker(child);
    }
  }, MAX_TASK_DURATION);

  function cleanup() {
    if (resolved) return;
    resolved = true;
    clearInterval(heartbeatTimer);
    clearTimeout(maxDurationTimer);
    activeWorkers.delete(taskId);
  }

  child.on('message', async (msg: WorkerMessage) => {
    if (!msg || typeof msg !== 'object') return;
    switch (msg.type) {
      case 'heartbeat':
        lastHeartbeat = Date.now();
        break;
      case 'progress':
        try {
          await repo.update({
            filterByTk: taskId,
            values: { processedRows: msg.processedRows, totalRows: msg.totalRows, progress: msg.progress },
          });
        } catch {
          /* 忽略 */
        }
        break;
      case 'log':
        try {
          await repo.create({ values: { taskId, level: msg.level, message: msg.message, timestamp: new Date() } });
        } catch {
          /* 忽略 */
        }
        break;
      case 'completed':
        break; // 在 exit 事件中统一处理
      case 'error':
        break; // 在 exit 事件中统一处理
    }
  });

  child.on('exit', (code, signal) => {
    cleanup();
    const exitOk = code === 0 && !signal;

    (async () => {
      if (exitOk) {
        // 正常退出：子进程已把文件路径写到了 sjgl02_tasks 的 fileName 字段
        // 这里需要创建 attachment 记录并更新 exportFileId
        try {
          const task = await repo.findOne({ filterByTk: taskId, raw: true });
          if (!task) return;
          const fileName = (task as any)?.fileName || '';
          if (!fileName) return;

          const { resolveAttachmentFromFile } = await import('../actions/export');
          const exportFileId = await resolveAttachmentFromFile(repo.db, fileName, taskId);
          if (exportFileId) {
            await repo.update({
              filterByTk: taskId,
              values: { exportFileId, status: 'completed', progress: 100, completedAt: new Date() },
            });
            await repo
              .create({
                values: {
                  taskId,
                  level: 'SUCC',
                  message: `导出完成，共 ${(task as any)?.processedRows || 0} 行数据`,
                  timestamp: new Date(),
                },
              })
              .catch(() => {});
          }
        } catch (err: any) {
          await repo.update({
            filterByTk: taskId,
            values: { status: 'failed', errorMessage: `收尾阶段失败: ${err.message}`, completedAt: new Date() },
          });
        }
      } else if (signal === 'SIGTERM' || signal === 'SIGKILL') {
        const task = await repo.findOne({ filterByTk: taskId, fields: ['status'] }).catch(() => null);
        if (!task) return;
        const status = (task as any)?.status;
        // 如果是用户取消，保留 cancelled 状态
        if (status !== 'cancelled') {
          await repo.update({
            filterByTk: taskId,
            values: { status: 'timeout', errorMessage: '任务执行超时', completedAt: new Date() },
          });
        }
      } else {
        await repo.update({
          filterByTk: taskId,
          values: { status: 'failed', errorMessage: `Worker exited with code ${code}`, completedAt: new Date() },
        });
      }
    })();
  });

  child.on('error', (err) => {
    cleanup();
    repo
      .update({
        filterByTk: taskId,
        values: { status: 'failed', errorMessage: `Worker error: ${err.message}`, completedAt: new Date() },
      })
      .catch(() => {});
    repo
      .create({ values: { taskId, level: 'ERROR', message: `Worker error: ${err.message}`, timestamp: new Date() } })
      .catch(() => {});
  });

  // 发送启动消息
  child.send(startMsg);

  return child;
}

/** 串行调度器：每隔 SCAN_INTERVAL 检查 pending 任务并启动 */
let schedulerInterval: ReturnType<typeof setInterval> | null = null;
let storedDb: Database | null = null;

/** 调度器核心：扫描并启动下一个导出/导入 pending 任务 */
const runSchedule = async () => {
  if (!storedDb) return;
  const db = storedDb;
  const repo = db.getRepository('sjgl02_tasks');
  try {
    // === 导出：检查并启动下一个 pending 任务 ===
    const processingCount = await repo.count({ filter: { taskType: 'export', status: 'processing' } });
    if (processingCount === 0) {
      const nextExport = await repo.findOne({
        filter: { taskType: 'export', status: 'pending' },
        sort: ['id'],
      });
      if (nextExport) {
        const taskId = (nextExport as any).id;
        const rec = nextExport as any;

        // 准备传给子进程的参数
        const headerStyle = rec.headerStyle || 'title_id';
        const includeAttachments = rec.includeAttachments || false;

        // 从 NocoBase collection 获取字段信息
        const coll = db.getCollection(rec.tableName);
        if (!coll) {
          await repo.update({
            filterByTk: taskId,
            values: { status: 'failed', errorMessage: `表 ${rec.tableName} 不存在`, completedAt: new Date() },
          });
          return;
        }

        // 获取字段名
        const selectedFields = rec.selectedFields || [];
        let fieldNames = selectedFields.length > 0 ? selectedFields : getScalarFieldNames(coll);
        if (!fieldNames?.length) {
          const belongsToFields = getRelationFieldNames(coll, ['belongsTo']);
          if (belongsToFields.length > 0) {
            fieldNames = belongsToFields;
          } else {
            fieldNames = getRelationFieldNames(coll, ['hasOne', 'hasMany', 'belongsToMany']);
          }
        }
        if (!fieldNames?.length) {
          await repo.update({
            filterByTk: taskId,
            values: { status: 'failed', errorMessage: '没有可导出的字段', completedAt: new Date() },
          });
          return;
        }

        // 获取字段显示名
        const fieldHeaders: Record<string, string> = {};
        for (const f of fieldNames) {
          fieldHeaders[f] = getFieldDisplayName(coll, f, headerStyle);
        }

        // 获取主键信息
        const pkInfo = detectPkStrategy(coll);
        const pkStrategy = pkInfo.strategy;
        const pkField = pkInfo.pkField;

        // 统计总行数
        let collectionTotal = 0;
        try {
          const tRepo = db.getRepository(rec.tableName);
          if (tRepo) collectionTotal = await tRepo.count({ filter: {} });
        } catch {
          /* 忽略 */
        }

        // 附件字段
        const attachmentFieldNames: string[] = includeAttachments ? getAttachFieldNames(coll) : [];
        const fileIdFieldNames: string[] = includeAttachments ? getFileIdFieldNames(coll) : [];

        // 表显示名
        const collDisplayName = getCollDisplayName(coll, headerStyle);

        // 更新状态
        await repo.update({
          filterByTk: taskId,
          values: { status: 'processing', totalRows: rec.totalRows || collectionTotal, startedAt: new Date() },
        });

        // fork
        const startMsg: StartMessage = {
          type: 'start',
          taskId,
          tableName: rec.tableName,
          fieldNames,
          filter: {},
          headerStyle,
          pkStrategy,
          pkField,
          collectionTotal,
          includeAttachments,
          attachmentFieldNames,
          fileIdFieldNames,
          fieldHeaders,
          collDisplayName,
          tempDir: resolveTempDir(),
        };

        forkExportWorker(taskId, startMsg, repo);
      }
    }

    // === 导入：检查并启动下一个 pending 任务 ===
    const importProcessingCount = await repo.count({ filter: { taskType: 'import', status: 'processing' } });
    if (importProcessingCount === 0) {
      const nextImport = await repo.findOne({
        filter: { taskType: 'import', status: 'pending' },
        sort: ['id'],
      });
      if (nextImport) {
        const taskId = (nextImport as any).id;
        await repo.update({ filterByTk: taskId, values: { status: 'processing', startedAt: new Date() } });
        importTimers.set(taskId, Date.now());

        // 导入在当前进程异步执行（它的 DB 操作 yield 事件循环）
        setImmediate(async () => {
          try {
            const { processImportAsync } = await import('../actions/import');
            const rec = nextImport as any;
            await processImportAsync(db, taskId, {
              tableName: rec.tableName,
              fileId: rec.importFileId,
              sheetName: rec.sheetName,
              headerRow: rec.headerRow,
              fieldMapping: rec.fieldMapping || {},
              customValues: rec.customValues || {},
              importMode: rec.importMode,
              uniqueFields: rec.uniqueFields || [],
              blankCellMode: rec.blankCellMode,
            });
          } catch {
            /* 已在 processImportAsync 内部处理 */
          } finally {
            importTimers.delete(taskId);
          }
        });
      }
    }

    // === 导入超时检查 ===
    for (const [tid, started] of importTimers) {
      if (Date.now() - started > MAX_TASK_DURATION) {
        try {
          const t = await repo.findOne({ filterByTk: tid, fields: ['status'] });
          if (t && (t as any)?.status === 'processing') {
            await repo.update({
              filterByTk: tid,
              values: { status: 'timeout', errorMessage: '任务执行超时', completedAt: new Date() },
            });
          }
        } catch {
          /* 忽略 */
        }
        importTimers.delete(tid);
      }
    }
  } catch {
    /* 调度器自身异常不传播 */
  }
};

export function startSerialScheduler(db: Database): void {
  if (schedulerInterval) return;
  storedDb = db;
  schedulerInterval = setInterval(runSchedule, SCAN_INTERVAL);
  runSchedule();
}

/** 由 executeExport 调用，立即触发调度器扫描一次（新提交的 pending 任务直接启动） */
export function triggerScheduler(): void {
  runSchedule();
}

export function stopSerialScheduler(): void {
  if (schedulerInterval) {
    clearInterval(schedulerInterval);
    schedulerInterval = null;
  }
  for (const [, child] of activeWorkers) {
    killWorker(child);
  }
  activeWorkers.clear();
}

// ========== 工具函数（从 export.ts 内联移到此处，供调度器使用） ==========

function resolveTempDir(): string {
  const storageDir = process.env.LOCAL_STORAGE_BASE_URL || process.env.STORAGE_DIR || 'storage/uploads';
  return path.join(storageDir, 'exports');
}

function sanitizeSheetName(name: string): string {
  return name.replace(/[\\/:*?[\]:!@#$%^&()]/g, '_').substring(0, 31);
}

function getScalarFieldNames(coll: any): string[] {
  if (!coll) return [];
  const names: string[] = [];
  try {
    for (const f of Array.from(coll.fields?.values() || coll.fields || [])) {
      const type = (f as any).type;
      if (!['belongsTo', 'hasOne', 'hasMany', 'belongsToMany'].includes(type)) {
        names.push((f as any).name);
      }
    }
  } catch {
    /* 忽略 */
  }
  return names;
}

function getRelationFieldNames(coll: any, types: string[]): string[] {
  if (!coll) return [];
  const names: string[] = [];
  try {
    for (const f of Array.from(coll.fields?.values() || coll.fields || [])) {
      if (types.includes((f as any).type)) {
        names.push((f as any).name);
      }
    }
  } catch {
    /* 忽略 */
  }
  return names;
}

function getFieldDisplayName(coll: any, fieldName: string, style?: string): string {
  try {
    const f = coll.fields instanceof Map ? coll.fields.get(fieldName) : null;
    const title = f?.options?.uiSchema?.title;
    if (title && !/^\{\{/.test(title)) {
      if (style === 'id') return fieldName;
      if (style === 'title') return title;
      return `${title}(${fieldName})`;
    }
  } catch {
    /* 忽略 */
  }
  return fieldName;
}

function getCollDisplayName(coll: any, style?: string): string {
  const rawName = coll?.name || '';
  let title = coll?.options?.title || rawName;
  if (/^\{\{/.test(title)) title = rawName;
  if (style === 'id') return rawName;
  if (style === 'title') return title;
  return title !== rawName ? `${title}(${rawName})` : rawName;
}

function detectPkStrategy(coll: any): { strategy: 'cursor' | 'uuid' | 'offset'; pkField: string | null } {
  try {
    const pkAttrs: string[] = coll.model?.primaryKeyAttributes || [];
    if (pkAttrs.length === 1) {
      const name = pkAttrs[0];
      const field = coll.fields?.get?.(name) || coll.fields?.[name];
      const type = String((field as any)?.type || 'other').toLowerCase();
      if (type.includes('uuid')) return { strategy: 'uuid', pkField: name };
      if ((type.includes('int') || type === 'bigint') && coll.model?.rawAttributes?.[name]?.autoIncrement) {
        return { strategy: 'cursor', pkField: name };
      }
      return { strategy: 'offset', pkField: name };
    }
  } catch {
    /* 忽略 */
  }
  return { strategy: 'offset', pkField: null };
}

function getAttachFieldNames(coll: any): string[] {
  if (!coll) return [];
  const names: string[] = [];
  try {
    for (const f of Array.from(coll.fields?.values() || coll.fields || [])) {
      if ((f as any).type === 'belongsToMany' && (f as any).options?.interface === 'attachment') {
        names.push((f as any).name);
      }
    }
  } catch {
    /* 忽略 */
  }
  return names;
}

function getFileIdFieldNames(coll: any): string[] {
  if (!coll) return [];
  const names: string[] = [];
  try {
    for (const f of Array.from(coll.fields?.values() || coll.fields || [])) {
      if ((f as any).type === 'integer' && /FileId$/.test((f as any).name)) {
        names.push((f as any).name);
      }
    }
  } catch {
    /* 忽略 */
  }
  return names;
}
