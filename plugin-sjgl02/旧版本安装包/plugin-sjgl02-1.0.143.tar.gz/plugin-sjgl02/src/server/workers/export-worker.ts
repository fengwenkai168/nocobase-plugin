/**
 * 导出子进程入口。
 * 由主进程通过 child_process.fork 启动。
 * 工作：连 PG → 分页查数据 → 流式写 Excel → IPC 汇报进度
 */

import { Database } from '@nocobase/database';
import ExcelJS from 'exceljs';
import fs from 'fs';
import path from 'path';
import type { ParentMessage, WorkerMessage } from './types';

const PAGE_SIZE = 2000;
const PROGRESS_INTERVAL = 30000; // 每 30 秒汇报一次进度

function getDbConfig() {
  return {
    username: process.env.DB_USER || 'nocobase',
    password: process.env.DB_PASSWORD || 'nocobase',
    database: process.env.DB_DATABASE || 'nocobase',
    host: process.env.DB_HOST || 'localhost',
    port: Number(process.env.DB_PORT) || 5432,
    dialect: 'postgres' as const,
    logging: false,
    define: { charset: 'utf8mb4', collate: 'utf8mb4_unicode_ci' },
    dialectOptions: { application_name: 'nocobase.export.worker' },
  };
}

function send(msg: WorkerMessage): void {
  if (process.send) process.send(msg);
}

function formatValue(val: any): string {
  if (val === null || val === undefined) return '';
  if (val instanceof Date) {
    const pad = (n: number) => String(n).padStart(2, '0');
    return `${val.getFullYear()}-${pad(val.getMonth() + 1)}-${pad(val.getDate())} ${pad(val.getHours())}:${pad(
      val.getMinutes(),
    )}:${pad(val.getSeconds())}`;
  }
  if (typeof val === 'object') return JSON.stringify(val);
  return String(val);
}

async function isCancelled(db: Database, taskId: number): Promise<boolean> {
  try {
    const [rows] = (await db.sequelize.query('SELECT "status" FROM "sjgl02_tasks" WHERE "id" = :id', {
      replacements: { id: taskId },
    })) as any[];
    return rows && (rows as any).status === 'cancelled';
  } catch {
    return false;
  }
}

async function runExport(msg: ParentMessage): Promise<void> {
  if (msg.type !== 'start') return;
  const {
    taskId,
    tableName,
    fieldNames,
    headerStyle,
    pkStrategy,
    pkField,
    collectionTotal,
    fieldHeaders,
    collDisplayName,
    tempDir,
  } = msg;

  send({
    type: 'log',
    level: 'INFO',
    message: `导出子进程启动，表: ${tableName}，字段: ${fieldNames.join(', ')}`,
  });

  const db = new Database(getDbConfig() as any);
  let cancelled = false;

  try {
    if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });

    const xlsxName = `sjgl02_export_${taskId}_${Date.now()}.xlsx`;
    const filePath = path.join(tempDir, xlsxName);

    const streamWriter = new ExcelJS.stream.xlsx.WorkbookWriter({
      filename: filePath,
      useStyles: true,
      useSharedStrings: false,
    });
    streamWriter.creator = 'NocoBase @my-project/plugin-sjgl02';

    const sheetName = collDisplayName.substring(0, 31).replace(/[\\/:*?[\]]/g, '_');
    const sheet = streamWriter.addWorksheet(sheetName);
    sheet.columns = fieldNames.map((f) => ({
      header: fieldHeaders[f] || f,
      key: f,
      width: Math.max((fieldHeaders[f] || f).length + 4, 20),
    }));
    (sheet.getRow(1) as any).font = { bold: true };
    (sheet.getRow(1) as any).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE0E0E0' } };

    const quotedTable = `"${tableName.replace(/"/g, '""')}"`;
    const quotedFields = fieldNames.map((f) => `"${f.replace(/"/g, '""')}"`).join(', ');
    let processedRows = 0;
    let lastProgressAt = Date.now();

    if (pkStrategy === 'cursor' && pkField) {
      let lastId = 0;
      let hasMore = true;
      while (hasMore) {
        if (await isCancelled(db, taskId)) {
          cancelled = true;
          hasMore = false;
          continue;
        }

        const sql = `SELECT ${quotedFields} FROM ${quotedTable} WHERE "${pkField}" > :lastId ORDER BY "${pkField}" LIMIT :limit`;
        const rows = (await db.sequelize.query(sql, {
          replacements: { lastId, limit: PAGE_SIZE },
        })) as any[];

        if (rows.length === 0) {
          hasMore = false;
          continue;
        }

        for (const row of rows) {
          const excelRow: Record<string, any> = {};
          for (const f of fieldNames) {
            excelRow[f] = formatValue(row[f]);
          }
          sheet.addRow(excelRow).commit();
          processedRows++;
        }

        lastId = Number(rows[rows.length - 1][pkField]);
        lastId = isNaN(lastId) ? 0 : lastId;

        if (Date.now() - lastProgressAt >= PROGRESS_INTERVAL) {
          const pct = Math.min(100, Math.floor((processedRows / Math.max(1, collectionTotal)) * 100));
          send({ type: 'progress', processedRows, totalRows: collectionTotal, progress: pct });
          send({ type: 'heartbeat', ts: Date.now() });
          lastProgressAt = Date.now();
        }
      }
    } else if (pkStrategy === 'uuid' && pkField) {
      try {
        await db.sequelize.query("SET SESSION statement_timeout = '30min'");
      } catch {
        /* 忽略 */
      }

      const allIds: any[] = [];
      let offset = 0;
      let hasMore = true;
      while (hasMore) {
        const sql = `SELECT "${pkField}" FROM ${quotedTable} ORDER BY "${pkField}" LIMIT :limit OFFSET :offset`;
        const rows = (await db.sequelize.query(sql, {
          replacements: { limit: PAGE_SIZE, offset },
        })) as any[];
        if (rows.length === 0) {
          hasMore = false;
          continue;
        }
        allIds.push(...rows.map((r: any) => r[pkField]));
        offset += PAGE_SIZE;
      }

      for (let bi = 0; bi < allIds.length; bi += PAGE_SIZE) {
        if (await isCancelled(db, taskId)) {
          cancelled = true;
          break;
        }
        const batch = allIds.slice(bi, bi + PAGE_SIZE);
        const placeholders = batch.map((_: any, i: number) => `:id${i}`).join(', ');
        const replacements: Record<string, any> = { limit: PAGE_SIZE };
        batch.forEach((id: any, i: number) => {
          replacements[`id${i}`] = id;
        });

        const sql = `SELECT ${quotedFields} FROM ${quotedTable} WHERE "${pkField}" IN (${placeholders}) LIMIT :limit`;
        const rows = (await db.sequelize.query(sql, { replacements })) as any[];

        for (const row of rows) {
          const excelRow: Record<string, any> = {};
          for (const f of fieldNames) {
            excelRow[f] = formatValue(row[f]);
          }
          sheet.addRow(excelRow).commit();
          processedRows++;
        }

        if (Date.now() - lastProgressAt >= PROGRESS_INTERVAL) {
          const pct = Math.min(100, Math.floor((processedRows / Math.max(1, allIds.length)) * 100));
          send({ type: 'progress', processedRows, totalRows: allIds.length, progress: pct });
          send({ type: 'heartbeat', ts: Date.now() });
          lastProgressAt = Date.now();
        }
      }
    } else {
      let offset = 0;
      while (offset < collectionTotal) {
        if (await isCancelled(db, taskId)) {
          cancelled = true;
          break;
        }
        const sql = `SELECT ${quotedFields} FROM ${quotedTable} ORDER BY 1 LIMIT :limit OFFSET :offset`;
        const rows = (await db.sequelize.query(sql, {
          replacements: { limit: PAGE_SIZE, offset },
        })) as any[];

        if (rows.length === 0) break;

        for (const row of rows) {
          const excelRow: Record<string, any> = {};
          for (const f of fieldNames) {
            excelRow[f] = formatValue(row[f]);
          }
          sheet.addRow(excelRow).commit();
          processedRows++;
        }

        offset += PAGE_SIZE;

        if (Date.now() - lastProgressAt >= PROGRESS_INTERVAL) {
          const pct = Math.min(100, Math.floor((offset * 100) / Math.max(1, collectionTotal)));
          send({ type: 'progress', processedRows, totalRows: collectionTotal, progress: pct });
          send({ type: 'heartbeat', ts: Date.now() });
          lastProgressAt = Date.now();
        }
      }
    }

    sheet.commit();
    await streamWriter.commit();

    if (cancelled) {
      try {
        fs.unlinkSync(filePath);
      } catch {
        /* 忽略 */
      }
      send({ type: 'log', level: 'WARN', message: '任务已取消' });
      await db.close();
      process.exit(0);
    }

    const stats = fs.statSync(filePath);
    send({ type: 'log', level: 'SUCC', message: `导出完成，共 ${processedRows} 行数据` });
    send({ type: 'completed', filePath, fileSize: stats.size, processedRows });
    await db.close();
    process.exit(0);
  } catch (err: any) {
    send({ type: 'log', level: 'ERROR', message: `导出失败: ${err.message}` });
    send({ type: 'error', message: err.message || String(err), stack: err.stack });
    try {
      await db.close();
    } catch {
      /* 忽略 */
    }
    process.exit(1);
  }
}

// ====== 入口 ======
process.on('message', (msg: ParentMessage) => {
  if (msg.type === 'start') runExport(msg);
  if (msg.type === 'cancel') {
    send({ type: 'log', level: 'WARN', message: '收到取消信号' });
    process.exit(0);
  }
});

send({ type: 'heartbeat', ts: Date.now() });
