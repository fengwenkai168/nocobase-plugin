import { defineCollection } from '@nocobase/database';

export default defineCollection({
  name: 'sjgl02_tasks',
  title: '导入导出任务',
  fields: [
    {
      interface: 'select',
      type: 'string',
      name: 'taskType',
      defaultValue: 'import',
      uiSchema: {
        enum: [
          { value: 'import', label: '导入' },
          { value: 'export', label: '导出' },
        ],
      },
    },
    { type: 'string', name: 'tableName' },
    { type: 'string', name: 'fileName' },
    {
      interface: 'select',
      type: 'string',
      name: 'status',
      defaultValue: 'pending',
      uiSchema: {
        enum: [
          { value: 'pending', label: '排队中' },
          { value: 'processing', label: '进行中' },
          { value: 'completed', label: '已完成' },
          { value: 'failed', label: '失败' },
          { value: 'cancelled', label: '已取消' },
        ],
      },
    },
    { type: 'json', name: 'fieldMapping' },
    { type: 'json', name: 'customValues' },
    { type: 'json', name: 'selectedFields' },
    { type: 'json', name: 'permSource' },
    { type: 'json', name: 'errorLogs' },
    { type: 'integer', name: 'progress', defaultValue: 0 },
    { type: 'integer', name: 'totalRows', defaultValue: 0 },
    { type: 'integer', name: 'processedRows', defaultValue: 0 },
    {
      interface: 'select',
      type: 'string',
      name: 'importMode',
      defaultValue: 'insert',
      uiSchema: {
        enum: [
          { value: 'insert', label: '新增' },
          { value: 'update', label: '更新' },
          { value: 'upsert', label: '新增+更新' },
        ],
      },
    },
    { type: 'string', name: 'sheetName' },
    { type: 'integer', name: 'headerRow', defaultValue: 1 },
    { type: 'json', name: 'uniqueFields' },
    { type: 'integer', name: 'importFileId' },
    { type: 'integer', name: 'exportFileId' },
    { type: 'text', name: 'errorMessage' },
    { type: 'boolean', name: 'includeAssociationSheet', defaultValue: false },
    { type: 'json', name: 'associationSheetTables' },
    { type: 'json', name: 'associationDisplayMode' },
    { type: 'boolean', name: 'includeAttachments', defaultValue: false },
    { type: 'json', name: 'requiredFields' },
    { type: 'string', name: 'blankCellMode', defaultValue: 'update' },
    { type: 'string', name: 'headerStyle', defaultValue: 'title_id' },
    { type: 'date', name: 'completedAt' },
    { type: 'belongsTo', name: 'createdBy', target: 'users', foreignKey: 'createdById' },
  ],
});
