import { Context, Next } from '@nocobase/actions';
import fs from 'fs';
import fsp from 'fs/promises';
import path from 'path';
import { checkExportPermission } from './permission-check';

function getFieldDisplayName(coll: any, fieldName: string, style?: string): string {
  try {
    const f = coll.fields instanceof Map ? coll.fields.get(fieldName) : null;
    const title = f?.options?.uiSchema?.title;
    if (title && !/^\{\{/.test(title)) {
      if (style === 'id') return fieldName;
      if (style === 'title') return title;
      return `${title}(${fieldName})`;
    }
  } catch {
    /* 忽略 */
  }
  return fieldName;
}

export async function getExportTableFields(ctx: Context, next: Next) {
  const { tableName } = ctx.action.params;
  if (!tableName || tableName === '__all__') {
    ctx.body = [];
    await next();
    return;
  }
  const coll: any = ctx.db.getCollection(tableName);
  if (!coll) {
    ctx.throw(404, `Table ${tableName} not found`);
  }
  let rawFields: any[] = [];
  try {
    rawFields = Array.from(coll.fields?.values() || coll.fields || []);
  } catch {
    rawFields = [];
  }
  const autoFields = ['id', 'createdAt', 'updatedAt', 'createdBy', 'updatedBy', 'createdById', 'updatedById'];
  const fkSet = new Set<string>();
  rawFields.forEach((f: any) => {
    if (f.type === 'belongsTo' && f.options?.foreignKey) {
      fkSet.add(f.options.foreignKey);
    }
  });
  const fields = rawFields
    .filter((f: any) => {
      return f.name !== 'createdBy' && f.name !== 'updatedBy';
    })
    .map((f: any) => {
      let title = f.options?.uiSchema?.title || null;
      if (title && /^\{\{/.test(title)) title = null;
      if (!title) title = f.name;
      return {
        name: f.name,
        type: f.type,
        uiSchema: { ...(f.options?.uiSchema || {}), title },
        interface: f.options?.interface || null,
        isRequired: autoFields.includes(f.name) ? false : f.options?.allowNull === false,
        isAssociation: ['belongsTo', 'hasOne', 'hasMany', 'belongsToMany'].includes(f.type),
        isForeignKey: fkSet.has(f.name),
      };
    });
  ctx.body = fields;
  await next();
}

export async function previewCount(ctx: Context, next: Next) {
  const params = ctx.action.params.values || ctx.action.params;
  const { tableName } = params;
  if (!tableName || tableName === '__all__') {
    let total = 0;
    const collections = ctx.db.collections;
    for (const [name, coll] of collections) {
      try {
        const repo = ctx.db.getRepository(name);
        if (repo) total += await repo.count({ filter: {} });
      } catch {
        /* 忽略 */
      }
    }
    ctx.body = { estimatedRows: total };
    await next();
    return;
  }
  const repo = ctx.db.getRepository(tableName);
  const count = repo ? await repo.count({ filter: {} }) : 0;
  ctx.body = { estimatedRows: count };
  await next();
}

export async function executeExport(ctx: Context, next: Next) {
  const params = ctx.action.params.values || ctx.action.params;
  const {
    tableName,
    selectedFields,
    associationDisplayMode,
    includeAssociationSheet,
    associationSheetTables,
    fileNameTemplate,
    includeAttachments,
    headerStyle,
    permSource,
  } = params;

  if (!tableName) {
    ctx.throw(400, 'tableName is required');
  }

  if (tableName !== '__all__') {
    const exportPerm = await checkExportPermission(ctx, tableName, permSource);
    if (exportPerm.exportFields && exportPerm.exportFields.length > 0 && selectedFields && selectedFields.length > 0) {
      const invalidFields = selectedFields.filter((f: string) => !exportPerm.exportFields.includes(f));
      if (invalidFields.length > 0) {
        ctx.throw(403, `您的权限不允许导出以下字段：${invalidFields.join('、')}，请联系管理员`);
      }
    }
  }

  let allowedTableList: string[] | null = null;
  if (tableName === '__all__') {
    const names: string[] = [];
    const collections = ctx.db.collections;
    for (const [name] of collections) {
      try {
        const permCheck = await checkExportPermission(ctx, name, permSource);
        if (permCheck.canExport) names.push(name);
      } catch {
        /* 忽略 */
      }
    }
    allowedTableList = names;
  }

  let estimatedTotal = 0;
  try {
    if (tableName === '__all__' && allowedTableList) {
      for (const t of allowedTableList) {
        try {
          const repo = ctx.db.getRepository(t);
          if (repo) estimatedTotal += await repo.count({ filter: {} });
        } catch {
          /* 忽略 */
        }
      }
    } else {
      const tRepo = ctx.db.getRepository(tableName);
      if (tRepo) estimatedTotal = await tRepo.count({ filter: {} });
    }
  } catch {
    /* 忽略 */
  }

  const repo = ctx.db.getRepository('sjgl02_tasks');
  const task = await repo.create({
    values: {
      taskType: 'export',
      tableName,
      status: 'pending',
      selectedFields: selectedFields || [],
      permSource: permSource || null,
      associationDisplayMode: associationDisplayMode || {},
      includeAssociationSheet: includeAssociationSheet || false,
      associationSheetTables: associationSheetTables || [],
      includeAttachments: includeAttachments || false,
      totalRows: estimatedTotal,
      progress: 0,
      fileName: tableName === '__all__' ? `全部数据表_${new Date().toISOString().slice(0, 10)}.tar.gz` : '',
      createdById: ctx.state.currentUser?.id,
      headerStyle: headerStyle || 'title_id',
    },
  });

  ctx.body = { taskId: task.id };
  await next();

  // 触发调度器检查，如果没有 processing 的任务则立即启动
  try {
    const { triggerScheduler } = require('../workers/zombie-guard');
    triggerScheduler();
  } catch {
    /* 忽略 */
  }
}

/**
 * 从 worker 生成的临时文件创建 attachment 记录，并重命名为可读文件名。
 * 由 zombie-guard 的 onWorkerExit 调用。
 */
export async function resolveAttachmentFromFile(db: any, tempFilePath: string, taskId: number): Promise<number | null> {
  try {
    const storageDir = process.env.LOCAL_STORAGE_BASE_URL || process.env.STORAGE_DIR || 'storage/uploads';
    const absPath = path.isAbsolute(tempFilePath) ? tempFilePath : path.join(storageDir, 'exports', tempFilePath);
    if (!fs.existsSync(absPath)) return null;

    const stats = await fsp.stat(absPath);
    const attachRepo = db.getRepository('attachments');
    const fileName = path.basename(absPath);
    const attachment = await attachRepo.create({
      values: {
        title: fileName,
        filename: fileName,
        extname: path.extname(absPath),
        mimetype: absPath.endsWith('.tar.gz')
          ? 'application/gzip'
          : 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        size: stats.size,
        path: path.relative(storageDir, absPath).replace(/\\/g, '/'),
      },
    });
    return attachment.id;
  } catch {
    return null;
  }
}

export async function getProgress(ctx: Context, next: Next) {
  const { taskId } = ctx.action.params;
  const repo = ctx.db.getRepository('sjgl02_tasks');
  const task = await repo.findOne({ filter: { id: taskId } });
  if (!task) {
    ctx.throw(404, 'Task not found');
  }
  ctx.body = {
    progress: task.progress,
    status: task.status,
    exportFileId: task.exportFileId,
  };
  await next();
}

export async function downloadExport(ctx: Context, next: Next) {
  const { taskId } = ctx.action.params;
  const repo = ctx.db.getRepository('sjgl02_tasks');
  const task = await repo.findOne({ filter: { id: taskId } });
  if (!task) {
    ctx.throw(404, 'Task not found');
  }
  if (!task.exportFileId) {
    ctx.throw(404, 'Export file not found');
  }
  const attachRepo = ctx.db.getRepository('attachments');
  const attachment = await attachRepo.findOne({ filter: { id: task.exportFileId } });
  if (!attachment) {
    ctx.throw(404, 'Attachment record not found');
  }
  const storageDir = process.env.LOCAL_STORAGE_BASE_URL || process.env.STORAGE_DIR || 'storage/uploads';
  const filePath = path.join(storageDir, attachment.path || attachment.filename);
  if (!fs.existsSync(filePath)) {
    ctx.throw(404, 'File not found on disk');
  }
  const fileName = attachment.title || attachment.filename || 'export.xlsx';
  ctx.attachment(encodeURIComponent(fileName));
  ctx.set('Content-Type', attachment.mimetype || 'application/octet-stream');
  ctx.body = fs.createReadStream(filePath);
  await next();
}
