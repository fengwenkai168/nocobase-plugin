/** 取消标志已改为 DB 字段驱动（sjgl02_tasks.status）。
 *  子进程每页检查 DB 中的 status 字段，不再依赖内存 Map。
 *  本文件保留为空占位，避免引用方报错。 */
export const cancelFlags: Set<number> = new Set();

