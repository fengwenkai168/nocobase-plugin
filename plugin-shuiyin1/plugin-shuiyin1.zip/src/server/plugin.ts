import { Plugin } from '@nocobase/server';
import { resolve } from 'path';
import { readFileSync } from 'fs';

export class PluginShuiyin1Server extends Plugin {
  async afterAdd() {}

  async beforeLoad() {}

  async load() {
    this.app.acl.allow('shuiyin1_settings', '*', 'loggedIn');

    // 同步版本号到数据库
    try {
      const repo = this.app.pm.repository;
      if (repo) {
        const item = await repo.findOne({ filter: { packageName: '@my-project/plugin-shuiyin1' } });
        if (item) {
          const pkg = require('../../package.json');
          if (item.get('version') !== pkg.version) {
            item.set('version', pkg.version);
            await item.save();
          }
        }
      }
    } catch (err) {
      this.logger?.warn?.('[shuiyin1] failed to sync version', err);
    }

    // 提供 README.md 访问路由
    this.app.use(async (ctx, next) => {
      if (ctx.path === '/api/plugins/@my-project/plugin-shuiyin1/readme') {
        const readmePath = resolve(__dirname, '../../README.md');
        try {
          const content = readFileSync(readmePath, 'utf8');
          ctx.body = `<!DOCTYPE html><html><head><meta charset="utf8"><title>水印插件说明</title><style>body{max-width:800px;margin:0 auto;padding:20px;font-family:sans-serif;line-height:1.6}code{background:#f4f4f4;padding:2px 6px;border-radius:3px}pre{background:#f4f4f4;padding:15px;border-radius:5px;overflow-x:auto}h1,h2,h3{border-bottom:1px solid #eee;padding-bottom:8px}</style></head><body><pre style="background:none;padding:0;white-space:pre-wrap;word-wrap:break-word">${content.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</pre></body></html>`;
          ctx.type = 'text/html; charset=utf8';
        } catch {
          ctx.status = 404;
          ctx.body = 'README not found';
        }
        return;
      }
      await next();
    });
  }

  async install() {
    const repo = this.db.getRepository('shuiyin1_settings');
    const count = await repo.count();
    if (count === 0) {
      await repo.create({
        values: {
          text: '',
          opacity: 0.15,
          fontSize: 10,
          showTime: true,
          density: 5,
        },
      });
    }
  }

  async afterEnable() {}

  async afterDisable() {}

  async remove() {}
}

export default PluginShuiyin1Server;
